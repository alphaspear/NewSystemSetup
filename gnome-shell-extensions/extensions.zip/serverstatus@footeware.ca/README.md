# serverstatus@footeware.ca

A gnome extension with indicator in task bar displaying status of entered web server URLs: 

- white for initializing
- green for up
- red for down 
- yellow for bad URL

The task bar shows the worst status from the set of all server statuses in the popup menu. Server down is considered worse than bad url.



![](assets/screenshot.png)
