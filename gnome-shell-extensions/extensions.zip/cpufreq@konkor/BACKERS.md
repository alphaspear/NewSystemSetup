---
title: Project's Supporters
permalink: /supporters/
description: Here could be your name, brand, reference and logo.
---

# People donated their **real money**

* #### [Miriam Laurel Inc](https://konkor.github.io/cpufreq/supporters/)

* #### [Julien MENNEGAND](https://konkor.github.io/cpufreq/supporters/)
* #### [Jonathan Alden](https://konkor.github.io/cpufreq/supporters/)
* #### [Manuel Transfeld](https://konkor.github.io/cpufreq/supporters/)
<br>

* **[Nikola Dyundev](https://konkor.github.io/cpufreq/supporters/)**
* **[Andreas Karnahl](https://konkor.github.io/cpufreq/supporters/)**
* **[Laurent Dumont](https://konkor.github.io/cpufreq/supporters/)**
* **[Pavels Kartasevs](https://konkor.github.io/cpufreq/supporters/)**
* **[Felipe Delestro Matos](https://konkor.github.io/cpufreq/supporters/)**
* **[Nikola Dyundev](https://konkor.github.io/cpufreq/supporters/)**
* **[Dirk Tol](https://konkor.github.io/cpufreq/supporters/)**
* **[Jun Chen](https://konkor.github.io/cpufreq/supporters/)**

* **[Roland Jungnickel](https://konkor.github.io/cpufreq/supporters/)**
* **[Joël Dinel](https://konkor.github.io/cpufreq/supporters/)**
* **[Michel Bonifert](https://konkor.github.io/cpufreq/supporters/)**
* **[Patrick Strobel](https://konkor.github.io/cpufreq/supporters/)**
<br><br>

* [Gerard Gos](https://konkor.github.io/cpufreq/supporters/)
* [Raven King](https://konkor.github.io/cpufreq/supporters/)
* [Mr W Alsafi](https://konkor.github.io/cpufreq/supporters/)
* [Thomas Hooper](https://konkor.github.io/cpufreq/supporters/)
* [Michele Barp](https://konkor.github.io/cpufreq/supporters/)
* [Matthew Hoelzel](https://konkor.github.io/cpufreq/supporters/)

* [Felix Emmert](https://konkor.github.io/cpufreq/supporters/)
* [Chun-Sheng Wu](https://konkor.github.io/cpufreq/supporters/)
* [Mark Graber](https://konkor.github.io/cpufreq/supporters/)
* [Samir Menon](https://konkor.github.io/cpufreq/supporters/)
* [Idan Bidani](https://konkor.github.io/cpufreq/supporters/)
* [Arnold Schröder](https://konkor.github.io/cpufreq/supporters/)
* [Adam Jones](https://konkor.github.io/cpufreq/supporters/)
* [Alibek Junisbayev](https://konkor.github.io/cpufreq/supporters/)
* [Térence Clastres](https://github.com/terencode)

## [Patreons](https://www.patreon.com/konkor)

* [Nick Krzemienski](https://github.com/krzemienski)
* [Ivan Chayka](https://vk.com/anaumynaugames)
* [Phenix Nunlee](https://www.patreon.com/user?u=21996172)
* [Steffen W.](https://www.patreon.com/user/creators?u=7405409)
* [Yoann Deferi](https://konkor.github.io/cpufreq/supporters/)
* [Tony](https://www.patreon.com/twu026)
* [Takao Sumitomo](https://www.patreon.com/user?u=21736175)
* [jasonium](https://www.patreon.com/user?u=711103)


# People donated their **own time**

## Coding and testing

* [Nailim](https://github.com/Nailim)
* [Gabriel Rauter](https://github.com/raetiacorvus)
* [balsoft](https://github.com/balsoft)
* [Ricardo Rodrigues](https://github.com/RicardoEPRodrigues)
* [Térence Clastres](https://github.com/terencode)
* [Derek W. Stavis](https://github.com/derekstavis)
* [Andre Breier](https://github.com/breier)
* [bjhulst](https://github.com/bjhulst)

## Documentation

* [Térence Clastres](https://github.com/terencode)
* [David](https://github.com/BurningSmile)

## Others

* Thanks to all testers and bug reporters.
* Thanks to your feedbacks on network resources.
* Thanks to all media creators mentioned, reviewed and shared it.

# YOUR NAME COULD BE HERE.
## LET'S SUPPORT IT NOW!

* [http://konkor.github.io/cpufreq/donations/](http://konkor.github.io/cpufreq/donations/)
* [http://konkor.github.io/cpufreq/supporters/](http://konkor.github.io/cpufreq/supporters/)
* [http://konkor.github.io/cpufreq/contributors/](http://konkor.github.io/cpufreq/contributors/)
